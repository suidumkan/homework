package com.company;

public enum Colors {
    BLACK,
    WHITE,
    BLUE,
    BROWN,
    GRAY
}
